<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\x65\154\x65\x63\164\157\x72\x2d\144\162\x6f\x70\x64\157\x77\156\40\160\x72\x2d\x62\x73\x73\x65\x6c\145\x63\164"; } }
