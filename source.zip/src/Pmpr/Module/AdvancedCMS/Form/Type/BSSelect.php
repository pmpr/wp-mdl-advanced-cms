<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\x65\x6c\145\x63\164\x6f\x72\55\x64\162\x6f\160\x64\x6f\167\x6e\x20\160\x72\x2d\x62\163\163\x65\x6c\145\143\x74"; } }
