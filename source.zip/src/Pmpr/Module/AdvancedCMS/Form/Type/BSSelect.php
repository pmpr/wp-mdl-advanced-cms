<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\x73\145\x6c\145\x63\x74\x6f\x72\55\144\x72\157\x70\x64\157\167\156\x20\160\162\x2d\142\163\163\145\x6c\x65\143\164"; } }
