<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class BSSelect extends Select { public function __construct() { parent::__construct(); } public function geecegsgyyayeouq() : string { return "\163\145\x6c\145\143\164\x6f\x72\x2d\144\162\157\x70\144\x6f\x77\156\40\x70\x72\55\142\x73\163\x65\x6c\145\x63\164"; } }
