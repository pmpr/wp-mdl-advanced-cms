<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Html extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), [Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $ekiuyucoiagmscgy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\143\x6f\x6e\164\x65\156\x74\137\143\142"); if ($ekiuyucoiagmscgy) { $aiowsaccomcoikus->args["\143\x6f\156\x74\x65\x6e\x74"] = call_user_func_array($aiowsaccomcoikus->args["\x63\x6f\156\164\x65\x6e\x74\137\143\x62"], [$aiowsaccomcoikus, $kqokimuosyuyyucg, $mqyaskyaekmkegmg]); } $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\144\x69\x76", $wwgucssaecqekuek, $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, Constants::ssmskyqgcmeiayco)); } }
