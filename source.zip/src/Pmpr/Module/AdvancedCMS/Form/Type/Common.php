<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\x6d\142\x32\137\162\x65\156\x64\145\162\x5f{$this->gueasuouwqysmomu()}", [$this, "\x72\145\156\x64\145\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x63\x6d\x62\62\137\163\141\156\x69\x74\x69\172\x65\x5f{$this->gueasuouwqysmomu()}", [$this, "\171\x69\x69\x69\x71\145\167\163\x73\x65\x79\167\x65\x6d\161\165"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return $this->caokeucsksukesyo()->owgcciayoweymuws()->sggauymmqugqouay($this); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
