<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\143\x6d\142\62\137\x72\145\x6e\x64\145\162\x5f{$this->gueasuouwqysmomu()}", [$this, "\x72\145\x6e\x64\145\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\143\155\x62\x32\137\163\141\x6e\x69\x74\x69\172\x65\x5f{$this->gueasuouwqysmomu()}", [$this, "\171\x69\151\x69\x71\x65\x77\163\163\x65\171\x77\145\155\161\x75"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return $this->caokeucsksukesyo()->owgcciayoweymuws()->sggauymmqugqouay($this); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
