<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Module\AdvancedCMS\Form\Common as BaseClass; class Common extends BaseClass { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x63\x6d\x62\x32\137\162\x65\x6e\144\x65\x72\137{$this->gueasuouwqysmomu()}", [$this, "\162\x65\x6e\x64\145\162"], 10, 5); parent::wigskegsqequoeks(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x63\x6d\x62\62\x5f\x73\x61\x6e\x69\164\151\x7a\145\137{$this->gueasuouwqysmomu()}", [$this, "\171\151\151\151\x71\x65\167\163\163\x65\171\167\145\x6d\161\165"], 10, 2); parent::kgquecmsgcouyaya(); } public function gueasuouwqysmomu() : string { return strtolower($this->ugwmakayykcmcmqa()); } public function yiiiqewsseywemqu($egomoiciasmiesww, $eqgoocgaqwqcimie) { return $egomoiciasmiesww; } public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { } }
