<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\143\164\157\162\55\x64\162\x6f\160\144\157\167\x6e\x20\x70\x72\55\163\145\154\145\x63\164\62"; } }
