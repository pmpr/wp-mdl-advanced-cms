<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\163\x65\154\x65\x63\164\157\x72\55\144\x72\157\x70\144\157\x77\x6e\x20\160\162\x2d\x73\x65\154\145\143\164\x32"; } }
