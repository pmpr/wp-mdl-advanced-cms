<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\x65\x6c\145\143\164\157\x72\55\144\162\157\160\x64\157\x77\156\40\160\162\x2d\x73\x65\154\145\143\164\x32"; } }
