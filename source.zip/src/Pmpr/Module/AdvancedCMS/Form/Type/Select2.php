<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\x73\145\154\145\143\164\157\162\55\144\162\157\x70\x64\x6f\x77\156\40\160\162\55\163\145\154\145\x63\164\62"; } }
