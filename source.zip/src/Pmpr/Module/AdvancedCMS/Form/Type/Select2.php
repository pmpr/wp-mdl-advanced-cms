<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; class Select2 extends Select { public function geecegsgyyayeouq() : string { return "\163\x65\154\x65\x63\164\157\x72\x2d\x64\162\157\160\144\157\167\156\40\160\162\x2d\163\145\154\145\143\x74\62"; } }
