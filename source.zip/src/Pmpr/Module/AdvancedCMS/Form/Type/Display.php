<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Type; use Pmpr\Common\Foundation\Interfaces\Constants; class Display extends Common { public function render($aiowsaccomcoikus, $eqgoocgaqwqcimie, $kqokimuosyuyyucg, $mqyaskyaekmkegmg, $ymygiwwuwyuakysk) { $eqgoocgaqwqcimie = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($aiowsaccomcoikus->args, "\166\x61\154\165\x65", $eqgoocgaqwqcimie); $wwgucssaecqekuek = $ymygiwwuwyuakysk->parse_args($this->gueasuouwqysmomu(), ["\x63\x6c\x61\x73\x73" => $aiowsaccomcoikus->args["\143\x6c\x61\x73\163\145\163"], Constants::NAME => $ymygiwwuwyuakysk->_name(), Constants::gouqcwikiiygyasc => $ymygiwwuwyuakysk->_id()]); $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sykissckqqccoiqs("\x64\151\166", $wwgucssaecqekuek, $eqgoocgaqwqcimie) . $ymygiwwuwyuakysk->_desc(true); } }
