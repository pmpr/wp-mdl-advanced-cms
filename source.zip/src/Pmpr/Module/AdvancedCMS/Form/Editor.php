<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\x63\145\x5f\x65\x78\x74\145\162\156\141\154\x5f\x70\154\x75\x67\151\156\163", [$this, "\157\141\x61\x65\x61\x6f\x75\155\x79\147\155\147\x63\x65\x61\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto syiqkaasoueowwui; } $mseykiqqcmyesccu["\x73\150\x6f\162\164\x63\157\x64\x65"] = $this->miocmcoykayoyyau()->get("\x74\x69\156\171\x6d\143\x65\55\x70\154\x75\x67\x69\156\56\152\x73"); syiqkaasoueowwui: return $mseykiqqcmyesccu; } }
