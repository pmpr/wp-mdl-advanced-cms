<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\145\137\x65\170\x74\145\x72\x6e\x61\x6c\x5f\160\x6c\x75\147\151\156\163", [$this, "\157\x61\141\145\x61\157\x75\155\171\x67\155\x67\x63\145\x61\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto ciucewqgyoiouesq; } $mseykiqqcmyesccu["\163\x68\x6f\162\164\143\157\x64\x65"] = $this->miocmcoykayoyyau()->get("\164\151\156\171\155\x63\145\55\160\x6c\x75\x67\x69\156\x2e\152\163"); ciucewqgyoiouesq: return $mseykiqqcmyesccu; } }
