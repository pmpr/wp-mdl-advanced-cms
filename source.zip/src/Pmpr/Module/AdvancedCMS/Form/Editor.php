<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\x63\x65\137\145\x78\x74\145\x72\156\x61\154\x5f\x70\154\165\x67\151\x6e\163", [$this, "\157\x61\141\145\x61\157\165\155\x79\x67\x6d\x67\x63\145\141\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\x73\x68\x6f\x72\x74\x63\157\144\x65"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\164\151\x6e\x79\x6d\x63\145\x2d\x70\x6c\x75\x67\x69\156\56\x6a\x73"); } return $mseykiqqcmyesccu; } }
