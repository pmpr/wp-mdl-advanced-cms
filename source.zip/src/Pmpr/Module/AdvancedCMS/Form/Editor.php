<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x6d\143\145\x5f\145\170\x74\145\162\156\141\154\137\160\154\165\x67\x69\156\x73", [$this, "\x6f\x61\141\x65\x61\157\165\155\x79\147\x6d\147\143\145\141\x73"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu["\163\x68\x6f\x72\164\143\x6f\x64\x65"] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, "\164\151\x6e\x79\155\x63\145\55\160\154\x75\147\151\x6e\56\x6a\163"); } return $mseykiqqcmyesccu; } }
