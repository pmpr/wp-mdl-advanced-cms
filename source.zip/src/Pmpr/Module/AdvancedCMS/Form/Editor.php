<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e283e018             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('mce_external_plugins', [$this, 'oaaeaoumygmgceas']); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if ($this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { $mseykiqqcmyesccu['shortcode'] = $this->caokeucsksukesyo()->usugyumcgeaaowsi()->aqmcwcyggeiyooyg($this, 'tinymce-plugin.js'); } return $mseykiqqcmyesccu; } }
