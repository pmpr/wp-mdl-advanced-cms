<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; class Editor extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\155\143\145\x5f\145\x78\164\145\162\x6e\141\154\x5f\x70\x6c\x75\x67\151\x6e\x73", [$this, "\157\141\141\145\x61\x6f\x75\x6d\171\147\x6d\147\x63\145\141\163"]); parent::kgquecmsgcouyaya(); } public function oaaeaoumygmgceas($mseykiqqcmyesccu) { if (!$this->caokeucsksukesyo()->ayueggmoqeeukqmq()->uqwgsuysegkweago([])) { goto syiqkaasoueowwui; } $mseykiqqcmyesccu["\163\150\x6f\x72\x74\x63\157\x64\x65"] = $this->miocmcoykayoyyau()->get("\x74\151\156\171\155\143\x65\55\160\154\x75\x67\151\156\x2e\152\x73"); syiqkaasoueowwui: return $mseykiqqcmyesccu; } }
