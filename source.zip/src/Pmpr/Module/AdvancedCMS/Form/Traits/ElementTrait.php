<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e283e018             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Traits; use Pmpr\Module\AdvancedCMS\Form as Forms; trait ElementTrait { public static function sgsmqaoowiyocqaa($aokagokqyuysuksm, $meqocwsecsywiiqs = null) : Forms\Tab { return new Forms\Tab($aokagokqyuysuksm, $meqocwsecsywiiqs); } public static function cgygmuguceeosoey($aokagokqyuysuksm, $meqocwsecsywiiqs = null, $yiyasiwyokuumigg = false) : Forms\MetaBox { return new Forms\MetaBox($aokagokqyuysuksm, $meqocwsecsywiiqs, $yiyasiwyokuumigg); } }
