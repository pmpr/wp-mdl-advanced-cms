<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Depended extends Checkbox { protected array $targets = []; public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, array $cwucaoaqgwqcwews = [], ?string $mkqqqewsokcswckc = null) { parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->yekmmasckowaowgc($cwucaoaqgwqcwews); $this->usoqcyyugsuyiewc("\144\145\x70\145\156\144\145\144"); } public function qammgescyicuwouu() : ?array { return $this->targets; } public function yekmmasckowaowgc($cwucaoaqgwqcwews) : self { $this->targets = $cwucaoaqgwqcwews; return $this; } }
