<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Html extends Field { protected $content = null; public function __construct(?string $aokagokqyuysuksm) { parent::__construct("\150\164\x6d\154", $aokagokqyuysuksm); } public function souwykwwmyygqyqi() { return $this->content; } public function oguessuismosauuu($ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
