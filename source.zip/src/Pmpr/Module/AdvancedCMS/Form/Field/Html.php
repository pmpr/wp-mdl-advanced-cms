<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Html extends Field { protected $content = null; public function __construct(?string $aokagokqyuysuksm) { parent::__construct("\x68\164\155\x6c", $aokagokqyuysuksm); } public function souwykwwmyygqyqi() { return $this->content; } public function oguessuismosauuu($ewgwqamkygiqaawc) : self { $this->content = $ewgwqamkygiqaawc; return $this; } }
