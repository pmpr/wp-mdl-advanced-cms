<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\x79\x73\x69\x77\x79\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\62\x5f\164\x65\170\x74\x61\x72\145\x61\x20\143\x6d\142\62\x2d\167\171\163\x69\167\x79\x67\x2d\x70\x6c\x61\x63\x65\150\x6f\154\x64\145\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\145\x78\x74\x61\x72\145\141\x5f\162\157\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\x65\x64\x69\141\x5f\142\165\x74\164\157\x6e\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\x69\x74\x6f\162\x5f\x63\x6c\141\x73\x73", $this->waecsyqmwascmqoa("\x63\x6c\141\163\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
