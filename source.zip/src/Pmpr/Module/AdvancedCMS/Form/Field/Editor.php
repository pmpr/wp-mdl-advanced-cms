<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\163\151\167\x79\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\x32\137\164\x65\x78\164\141\x72\145\141\x20\x63\155\x62\x32\x2d\x77\171\x73\151\167\x79\147\55\160\x6c\141\143\145\x68\157\x6c\144\145\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\x65\170\x74\141\x72\145\141\137\162\x6f\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\145\x64\151\x61\x5f\x62\x75\x74\x74\x6f\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\144\x69\x74\157\x72\x5f\143\154\141\163\x73", $this->waecsyqmwascmqoa("\x63\154\x61\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
