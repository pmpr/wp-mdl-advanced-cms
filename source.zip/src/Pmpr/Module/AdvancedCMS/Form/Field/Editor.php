<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\167\171\163\x69\x77\x79\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\x63\155\142\62\137\164\x65\x78\164\141\x72\145\141\40\x63\155\142\62\55\x77\x79\163\x69\167\x79\147\x2d\160\154\x61\143\x65\150\x6f\x6c\x64\x65\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\145\x78\164\x61\162\x65\141\137\x72\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\155\145\x64\x69\141\137\x62\165\164\164\x6f\x6e\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\144\151\x74\x6f\x72\137\143\x6c\x61\163\x73", $this->waecsyqmwascmqoa("\143\154\x61\163\163")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
