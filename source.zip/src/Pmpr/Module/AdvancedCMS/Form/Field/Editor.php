<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\171\x73\x69\x77\x79\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\x6d\142\x32\x5f\164\145\170\164\141\x72\x65\x61\40\143\155\142\62\55\x77\171\163\151\167\x79\147\55\160\x6c\x61\x63\x65\x68\x6f\x6c\144\x65\x72"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\x65\x78\164\x61\162\x65\141\137\162\x6f\167\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\x65\x64\x69\x61\x5f\142\165\x74\164\157\x6e\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\144\x69\x74\x6f\x72\x5f\143\154\x61\x73\163", $this->waecsyqmwascmqoa("\143\x6c\141\163\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
