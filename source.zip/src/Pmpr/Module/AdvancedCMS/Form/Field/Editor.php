<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\x73\151\167\171\x67", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\155\x62\62\x5f\164\145\170\x74\141\x72\145\x61\x20\x63\x6d\142\62\x2d\x77\x79\x73\151\167\171\147\55\160\x6c\141\x63\145\x68\157\154\144\x65\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\x74\x65\170\164\141\162\145\x61\x5f\x72\x6f\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\x65\x64\x69\141\x5f\x62\x75\164\164\x6f\156\x73", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\x65\x64\151\x74\157\x72\x5f\143\x6c\x61\x73\x73", $this->waecsyqmwascmqoa("\143\x6c\141\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
