<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Editor extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null, array $qiouiwasaauyaaue = []) { $this->sanitizer = null; parent::__construct("\x77\x79\163\151\x77\x79\147", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, $qiouiwasaauyaaue); $this->qigsyyqgewgskemg("\143\x6d\142\x32\x5f\x74\x65\x78\x74\x61\162\145\x61\40\x63\155\142\62\55\x77\x79\163\x69\167\171\x67\x2d\x70\x6c\141\143\x65\150\157\x6c\144\x65\162"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->kesomeowemmyygey("\164\x65\170\x74\x61\162\145\x61\137\162\157\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function gsomueooycksswcy() : self { $this->kesomeowemmyygey("\x6d\145\144\151\x61\x5f\142\x75\164\164\157\156\163", false); return $this; } public function qgsieamsswkgysow(array $ywmkwiwkosakssii = []) : void { $this->kesomeowemmyygey("\145\144\x69\x74\157\x72\x5f\143\x6c\141\163\163", $this->waecsyqmwascmqoa("\x63\154\x61\x73\x73")); parent::qgsieamsswkgysow($ywmkwiwkosakssii); } }
