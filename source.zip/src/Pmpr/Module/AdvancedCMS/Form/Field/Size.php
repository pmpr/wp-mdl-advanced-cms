<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Size extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x73\x69\x7a\145", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function eyygsasuqmommkua($qeswwaqqsyymqawg = 50, $cswemwoyesycwkuq = 50) : Field { return parent::eyygsasuqmommkua(["\x77\x69\x64\164\150" => $qeswwaqqsyymqawg, "\150\145\151\147\x68\164" => $cswemwoyesycwkuq]); } }
