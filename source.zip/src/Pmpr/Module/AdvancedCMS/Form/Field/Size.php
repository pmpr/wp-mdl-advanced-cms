<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Size extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x73\151\x7a\145", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function eyygsasuqmommkua($qeswwaqqsyymqawg = 50, $cswemwoyesycwkuq = 50) : Field { return parent::eyygsasuqmommkua(["\167\x69\144\x74\x68" => $qeswwaqqsyymqawg, "\150\x65\x69\x67\150\x74" => $cswemwoyesycwkuq]); } }
