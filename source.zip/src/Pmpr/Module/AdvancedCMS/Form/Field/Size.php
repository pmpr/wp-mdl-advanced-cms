<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e283e018             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Size extends Field { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct('size', $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); } public function eyygsasuqmommkua($qeswwaqqsyymqawg = 50, $cswemwoyesycwkuq = 50) : Field { return parent::eyygsasuqmommkua(['width' => $qeswwaqqsyymqawg, 'height' => $cswemwoyesycwkuq]); } }
