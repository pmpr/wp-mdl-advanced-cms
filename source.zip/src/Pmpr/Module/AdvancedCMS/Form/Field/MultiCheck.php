<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e283e018             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class MultiCheck extends OptionAwareField { protected bool $inline = false; public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?array $qiouiwasaauyaaue, ?string $ukwokcuqauuosmoo = null) { parent::__construct('multicheck', $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $ukwokcuqauuosmoo, $qiouiwasaauyaaue); $this->usoqcyyugsuyiewc('pr-switch'); } public function wmociykwcyesssui() : ?bool { return $this->inline; } public function awagieqcmmwkgwgs(bool $usyqkyomqcuocgoa) : self { $this->inline = $usyqkyomqcuocgoa; return $this; } }
