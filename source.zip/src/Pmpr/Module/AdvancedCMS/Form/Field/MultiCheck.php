<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class MultiCheck extends OptionAwareField { protected bool $inline = false; public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?array $qiouiwasaauyaaue, ?string $ukwokcuqauuosmoo = null) { parent::__construct("\x6d\165\154\x74\x69\143\x68\145\143\x6b", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $ukwokcuqauuosmoo, $qiouiwasaauyaaue); $this->usoqcyyugsuyiewc("\160\x72\x2d\163\x77\x69\164\143\x68"); } public function wmociykwcyesssui() : ?bool { return $this->inline; } public function awagieqcmmwkgwgs(bool $usyqkyomqcuocgoa) : self { $this->inline = $usyqkyomqcuocgoa; return $this; } }
