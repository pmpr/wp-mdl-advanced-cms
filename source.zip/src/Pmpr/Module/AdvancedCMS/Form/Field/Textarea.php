<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\x6e\x69\164\151\172\x65\137\x74\145\170\164\141\x72\x65\141\x5f\146\151\x65\154\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\170\164\141\x72\145\x61"); $this->qigsyyqgewgskemg("\x63\155\x62\x32\x5f\164\x65\170\x74\x61\162\x65\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\x6f\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\145\170\164\141\x72\x65\x61\x5f\143\x6f\144\x65"); $this->sanitizer = [$this, "\145\x6b\147\157\x6f\157\x69\147\x61\145\x69\x6b\167\145\x6b\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
