<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\141\x6e\151\164\x69\x7a\x65\x5f\x74\145\170\x74\141\162\145\x61\x5f\146\151\145\154\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\145\x78\x74\141\162\x65\141"); $this->qigsyyqgewgskemg("\x63\155\x62\x32\137\x74\x65\170\x74\141\162\145\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\x72\x6f\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\145\170\164\141\162\145\x61\x5f\x63\157\x64\145"); $this->sanitizer = [$this, "\145\x6b\x67\157\157\x6f\x69\147\x61\145\x69\x6b\167\145\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
