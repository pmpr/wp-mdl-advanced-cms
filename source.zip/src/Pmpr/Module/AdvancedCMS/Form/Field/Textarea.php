<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\141\156\151\164\151\172\x65\137\x74\145\x78\164\x61\162\x65\141\x5f\146\x69\145\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\145\x78\164\141\x72\x65\x61"); $this->qigsyyqgewgskemg("\x63\155\x62\62\137\x74\145\x78\x74\x61\x72\145\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\x77\x73", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\x74\145\170\164\141\162\x65\x61\137\143\157\x64\145"); $this->sanitizer = [$this, "\145\153\x67\x6f\157\x6f\x69\x67\141\x65\x69\153\167\145\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
