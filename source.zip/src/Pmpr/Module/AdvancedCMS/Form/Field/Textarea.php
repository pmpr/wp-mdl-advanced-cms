<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\163\x61\156\151\x74\151\172\x65\137\164\x65\x78\x74\141\162\x65\x61\x5f\x66\x69\x65\x6c\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\170\164\141\x72\145\141"); $this->qigsyyqgewgskemg("\x63\x6d\x62\x32\x5f\x74\x65\170\x74\x61\x72\145\141"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\157\x77\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\x65\170\164\141\162\x65\x61\137\x63\157\x64\145"); $this->sanitizer = [$this, "\145\x6b\147\x6f\x6f\157\151\x67\141\x65\151\x6b\167\145\153\167"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
