<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\141\x6e\x69\x74\151\x7a\145\137\164\x65\x78\x74\x61\162\145\141\x5f\146\151\x65\x6c\x64"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\x74\145\170\x74\141\162\x65\x61"); $this->qigsyyqgewgskemg("\x63\155\142\62\x5f\x74\145\170\x74\141\x72\x65\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\x6f\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\x65\x78\164\x61\x72\145\141\137\143\157\144\145"); $this->sanitizer = [$this, "\145\x6b\147\157\x6f\x6f\151\147\x61\145\151\153\167\145\x6b\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
