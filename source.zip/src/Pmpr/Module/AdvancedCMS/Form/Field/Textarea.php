<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Textarea extends Text { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo, ?string $mkqqqewsokcswckc = null) { $this->sanitizer = "\x73\x61\x6e\x69\x74\151\x7a\x65\x5f\x74\x65\x78\164\141\x72\145\141\x5f\146\151\145\154\144"; parent::__construct($aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc, "\164\x65\170\x74\141\x72\x65\x61"); $this->qigsyyqgewgskemg("\143\x6d\x62\x32\137\x74\145\170\x74\x61\x72\x65\x61"); } public function qsecygiycssgacqs($essikcmqiyqaqoaq) : self { $this->qcgocuceocquqcuw("\162\x6f\167\163", (string) $essikcmqiyqaqoaq); return $this; } public function wcgckeeiiseccqkc() : self { $this->aseocggwwegcmqes("\164\x65\170\164\x61\162\145\x61\137\143\157\x64\145"); $this->sanitizer = [$this, "\x65\x6b\x67\x6f\x6f\157\x69\x67\141\145\x69\153\167\145\153\x77"]; return $this; } public function ekgoooigaeikwekw($cmwygeyygwqaemaq) { return $cmwygeyygwqaemaq; } }
