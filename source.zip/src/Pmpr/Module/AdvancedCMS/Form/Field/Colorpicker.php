<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Colorpicker extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\143\157\x6c\x6f\x72\x70\151\143\153\x65\162", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->kesomeowemmyygey("\141\x6c\x70\x68\141", true)->qigsyyqgewgskemg("\x63\x6f\154\157\x72\55\x70\x69\x63\x6b\x65\162")->eskgwaywimqcwcyy("\143\x6f\x6c\157\x72\160\151\x63\x6b\x65\x72", ''); add_action("\x61\144\155\x69\x6e\x5f\146\x6f\x6f\164\145\x72", [$this, "\145\x6e\x71\165\145\x75\145"], 9999); } public function enqueue() { wp_enqueue_script("\x77\x70\x2d\x63\x6f\154\157\162\55\x70\x69\x63\153\145\x72"); wp_enqueue_script("\x77\160\55\143\x6f\154\x6f\x72\x2d\160\x69\x63\x6b\145\x72\55\x61\154\160\x68\x61"); } }
