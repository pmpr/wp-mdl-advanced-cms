<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form\Field; class Colorpicker extends OptionAwareField { public function __construct(?string $aokagokqyuysuksm, ?string $ymqmyyeuycgmigyo = null, ?string $mkqqqewsokcswckc = null) { parent::__construct("\x63\x6f\x6c\157\162\160\x69\143\153\145\x72", $aokagokqyuysuksm, $ymqmyyeuycgmigyo, $mkqqqewsokcswckc); $this->kesomeowemmyygey("\141\154\x70\x68\141", true)->qigsyyqgewgskemg("\x63\157\154\157\162\55\160\x69\x63\153\145\x72")->eskgwaywimqcwcyy("\x63\157\x6c\157\x72\x70\151\143\153\145\162", ''); add_action("\x61\144\155\x69\x6e\137\x66\x6f\157\x74\x65\162", [$this, "\x65\x6e\161\x75\x65\x75\x65"], 9999); } public function enqueue() { wp_enqueue_script("\167\160\x2d\143\x6f\x6c\157\x72\55\160\151\143\x6b\x65\x72"); wp_enqueue_script("\167\x70\x2d\143\x6f\x6c\x6f\162\x2d\x70\x69\x63\153\145\x72\55\x61\x6c\160\150\141"); } }
