<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->couwksyewgyeooqe()->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\57\156\141\x72\155\141\146\x7a\x61\x6d\57\143\155\142\62\x2f\x69\156\x69\164\56\160\150\x70"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x76\145\x6e\x64\157\162\x2f{$mkomwsiykqigmqca}")) { goto eogwckcymuugikuy; } if (!$iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\56\56\57\x2e\56\x2f{$mkomwsiykqigmqca}")) { goto eeauyscekuckoues; } require_once "{$couygeouymagssgw}\57\56\56\x2f\x2e\56\x2f{$mkomwsiykqigmqca}"; eeauyscekuckoues: goto msemumccgceyugmg; eogwckcymuugikuy: require_once "{$couygeouymagssgw}\x2f\166\145\x6e\x64\157\x72\x2f{$mkomwsiykqigmqca}"; msemumccgceyugmg: } }
