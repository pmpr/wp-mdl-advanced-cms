<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->get($this)->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\57\156\x61\x72\155\141\x66\x7a\141\155\57\x63\155\x62\62\x2f\x69\x6e\x69\x74\56\x70\x68\160"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\x2f\x76\x65\156\144\x6f\x72\57{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}\x2f\x76\x65\x6e\144\157\162\57{$mkomwsiykqigmqca}"; } else { if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x2e\56\x2f\x2e\x2e\x2f{$mkomwsiykqigmqca}")) { require_once "{$couygeouymagssgw}\57\56\x2e\57\56\x2e\x2f{$mkomwsiykqigmqca}"; } } } }
