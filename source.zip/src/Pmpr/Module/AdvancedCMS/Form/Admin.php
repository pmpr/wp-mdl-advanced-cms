<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Form; use Pmpr\Module\AdvancedCMS\Form\Type\Type; class Admin extends Common { public function mameiwsayuyquoeq() { $this->kqmyggcqsgeyyicg(); Type::ksyueceqagwomguk(); CMB2::ksyueceqagwomguk(); Editor::ksyueceqagwomguk(); } public function kqmyggcqsgeyyicg() { $iiaumsgauuyeqksw = $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk(); $couygeouymagssgw = $this->couwksyewgyeooqe()->ikeqsmumgwwuqmkw(); $mkomwsiykqigmqca = "\57\x6e\141\x72\155\141\x66\172\x61\x6d\x2f\x63\155\142\62\57\x69\x6e\151\x74\56\x70\150\x70"; if ($iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x76\x65\156\144\157\162\x2f{$mkomwsiykqigmqca}")) { goto skkamseieeusycye; } if (!$iiaumsgauuyeqksw->exists("{$couygeouymagssgw}\57\x2e\56\x2f\56\56\57{$mkomwsiykqigmqca}")) { goto wiysogeqqwgioyka; } require_once "{$couygeouymagssgw}\57\x2e\x2e\57\x2e\56\x2f{$mkomwsiykqigmqca}"; wiysogeqqwgioyka: goto cgiscsqwwgqqaeqi; skkamseieeusycye: require_once "{$couygeouymagssgw}\x2f\x76\145\156\144\x6f\162\x2f{$mkomwsiykqigmqca}"; cgiscsqwwgqqaeqi: } }
