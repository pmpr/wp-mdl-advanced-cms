<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a435003b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
