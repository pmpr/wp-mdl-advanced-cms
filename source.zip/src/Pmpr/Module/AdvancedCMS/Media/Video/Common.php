<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media\Video; use Pmpr\Module\AdvancedCMS\Container; abstract class Common extends Container { }
