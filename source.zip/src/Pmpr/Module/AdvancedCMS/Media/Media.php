<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Media\Video\Video; class Media extends Common { public function mameiwsayuyquoeq() { Video::symcgieuakksimmu(); } }
