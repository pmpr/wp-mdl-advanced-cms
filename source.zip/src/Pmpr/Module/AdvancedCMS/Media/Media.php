<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Container; use Pmpr\Module\AdvancedCMS\Media\Video\Aparat; class Media extends Container { public function mameiwsayuyquoeq() { Aparat::symcgieuakksimmu(); } }
