<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Media\Video\Video; class Media extends Common { public function mameiwsayuyquoeq() { Video::symcgieuakksimmu(); } }
