<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Media\Video\Video; class Media extends Common { public function mameiwsayuyquoeq() { Video::symcgieuakksimmu(); } }
