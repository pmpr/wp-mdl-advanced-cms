<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Media; use Pmpr\Module\AdvancedCMS\Media\Video\Video; class Media extends Common { public function mameiwsayuyquoeq() { Video::symcgieuakksimmu(); } }
