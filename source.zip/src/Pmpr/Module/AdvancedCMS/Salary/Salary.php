<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Salary; use Pmpr\Module\Salary\AbstractSalary; class Salary extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = __("\x41\144\166\141\156\x63\x65\144\40\103\x4d\x53\40\x4d\x6f\144\x75\154\145", PR__MDL__ADVANCED_CMS); } public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { $oeucsuyqysaciasy = $this->yceacaoomkmkesym($xssuewsokckmigqk); $okycmmskgswewacc = []; switch ($oeucsuyqysaciasy) { case self::iwascisiiokuackw: if (!($post = $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->awacsmgimwaqmuga($cawesmkieccckaae, Product::wsuoiieigayeicyc))) { goto wwkgkaecgiwggcck; } $qscaoekmoooeuyqg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->mguqscccckuywsya($post, true); if (!($aqmwamyiwgeeymqa = $this->rkwqmomqeowwyaam($xssuewsokckmigqk, $qscaoekmoooeuyqg))) { goto kciouyuaqkyqomam; } $okycmmskgswewacc[] = $aqmwamyiwgeeymqa; kciouyuaqkyqomam: wwkgkaecgiwggcck: goto sycygoiaiqqageym; } gygawoqywkukmqee: sycygoiaiqqageym: return $okycmmskgswewacc; } }
