<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Salary; use Pmpr\Module\Salary\AbstractSalary; class Salary extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = __("\101\144\166\141\156\x63\x65\x64\40\103\x4d\x53\x20\x4d\157\144\165\154\145", PR__MDL__ADVANCED_CMS); } public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { $oeucsuyqysaciasy = $this->yceacaoomkmkesym($xssuewsokckmigqk); $okycmmskgswewacc = []; switch ($oeucsuyqysaciasy) { case self::iwascisiiokuackw: if (!($post = $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->awacsmgimwaqmuga($cawesmkieccckaae, Product::wsuoiieigayeicyc))) { goto eequksumcoogyoem; } $qscaoekmoooeuyqg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->mguqscccckuywsya($post, true); if (!($aqmwamyiwgeeymqa = $this->rkwqmomqeowwyaam($xssuewsokckmigqk, $qscaoekmoooeuyqg))) { goto sqiciiuwmykocycc; } $okycmmskgswewacc[] = $aqmwamyiwgeeymqa; sqiciiuwmykocycc: eequksumcoogyoem: goto kiqogmwcgcamwiig; } iomcaiwewsawiamu: kiqogmwcgcamwiig: return $okycmmskgswewacc; } }
