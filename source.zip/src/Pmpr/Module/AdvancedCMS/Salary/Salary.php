<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd214a48270             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Salary; use Pmpr\Module\Salary\AbstractSalary; class Salary extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = __("\101\x64\166\141\x6e\x63\145\144\40\x43\x4d\123\x20\x4d\157\x64\x75\x6c\x65", PR__MDL__ADVANCED_CMS); } public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { $oeucsuyqysaciasy = $this->yceacaoomkmkesym($xssuewsokckmigqk); $okycmmskgswewacc = []; switch ($oeucsuyqysaciasy) { case self::iwascisiiokuackw: if (!($post = $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->awacsmgimwaqmuga($cawesmkieccckaae, Product::wsuoiieigayeicyc))) { goto qgoiooayqmqqsiok; } $qscaoekmoooeuyqg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->mguqscccckuywsya($post, true); if (!($aqmwamyiwgeeymqa = $this->rkwqmomqeowwyaam($xssuewsokckmigqk, $qscaoekmoooeuyqg))) { goto qogqewiwmwiwskgm; } $okycmmskgswewacc[] = $aqmwamyiwgeeymqa; qogqewiwmwiwskgm: qgoiooayqmqqsiok: goto cecuyayqoioasumi; } qiaqsassksqiuyae: cecuyayqoioasumi: return $okycmmskgswewacc; } }
