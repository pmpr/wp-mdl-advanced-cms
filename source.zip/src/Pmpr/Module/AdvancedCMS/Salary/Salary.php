<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfe0898f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Salary; use Pmpr\Module\Salary\AbstractSalary; class Salary extends AbstractSalary { public function ikcgmcycisiccyuc() { $this->title = __("\x41\144\x76\141\156\143\145\x64\x20\103\115\123\40\x4d\x6f\x64\165\x6c\145", PR__MDL__ADVANCED_CMS); } public function mameiwsayuyquoeq() { Product::symcgieuakksimmu(); } public function ksikyqoayeggqssg($xssuewsokckmigqk, $cawesmkieccckaae, $product) : array { $oeucsuyqysaciasy = $this->yceacaoomkmkesym($xssuewsokckmigqk); $okycmmskgswewacc = []; switch ($oeucsuyqysaciasy) { case self::iwascisiiokuackw: if (!($post = $this->uwkmaywceaaaigwo()->wikusamwomuogoau()->awacsmgimwaqmuga($cawesmkieccckaae, Product::wsuoiieigayeicyc))) { goto eequksumcoogyoem; } $qscaoekmoooeuyqg = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->mguqscccckuywsya($post, true); if (!($aqmwamyiwgeeymqa = $this->rkwqmomqeowwyaam($xssuewsokckmigqk, $qscaoekmoooeuyqg))) { goto sqiciiuwmykocycc; } $okycmmskgswewacc[] = $aqmwamyiwgeeymqa; sqiciiuwmykocycc: eequksumcoogyoem: goto kiqogmwcgcamwiig; } iomcaiwewsawiamu: kiqogmwcgcamwiig: return $okycmmskgswewacc; } }
