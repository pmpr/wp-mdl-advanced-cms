<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f0bb597             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormMaker\Admin\SettingTab; class Tab extends SettingTab { public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
