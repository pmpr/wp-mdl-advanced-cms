<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x53\x65\164\164\x69\156\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\x41\144\x76\141\x6e\143\x65\x64\40\x43\115\x53\x20\123\145\x74\x74\x69\156\147", PR__MDL__ADVANCED_CMS)); } }
