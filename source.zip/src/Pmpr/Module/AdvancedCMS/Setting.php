<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\145\x74\x74\x69\x6e\x67", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\x41\144\x76\141\156\x63\x65\x64\x20\103\x4d\x53\40\123\x65\164\164\x69\x6e\x67", PR__MDL__ADVANCED_CMS)); } }
