<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfe0898f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\145\164\164\x69\156\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\x41\x64\x76\x61\x6e\143\145\144\40\103\115\x53\x20\x53\145\x74\x74\x69\156\147", PR__MDL__ADVANCED_CMS)); } }
