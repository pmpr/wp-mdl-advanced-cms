<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\x65\164\164\151\x6e\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\101\x64\166\x61\x6e\143\145\144\40\x43\x4d\123\40\x53\145\164\164\x69\156\x67", PR__MDL__ADVANCED_CMS)); } }
