<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\145\x74\x74\x69\156\x67", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(Constants::ysgwugcqguggmigq, __("\101\144\x76\x61\x6e\x63\x65\x64\x20\x43\115\123\x20\123\145\x74\x74\151\156\x67", PR__MDL__ADVANCED_CMS)); } }
