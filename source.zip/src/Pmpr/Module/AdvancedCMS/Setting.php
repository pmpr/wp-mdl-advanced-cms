<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bd44842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\123\x65\x74\164\x69\156\147", PR__MDL__ADVANCED_CMS); $this->igiywquyccyiaucw(self::ysgwugcqguggmigq, __("\101\144\x76\x61\156\x63\x65\144\x20\103\x4d\x53\x20\123\x65\164\x74\x69\x6e\x67", PR__MDL__ADVANCED_CMS)); } }
