<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\x74\141\162\164\40\x53\150\x6f\x72\x74\x63\157\144\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\x61\x73\x5f\x63\157\156\164\141\151\x6e\145\162", __("\x48\141\x73\40\x43\157\x6e\164\x61\151\x6e\x65\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
