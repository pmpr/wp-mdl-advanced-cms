<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\x74\x61\x72\x74\40\123\x68\157\x72\164\143\157\x64\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\163\x5f\x63\157\x6e\x74\x61\x69\x6e\145\x72", __("\110\141\163\x20\103\x6f\156\164\141\151\x6e\x65\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
