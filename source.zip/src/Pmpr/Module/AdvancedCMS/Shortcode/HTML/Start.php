<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\141\162\164\x20\x53\x68\157\162\164\x63\x6f\x64\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\x73\137\x63\x6f\x6e\164\x61\x69\156\145\162", __("\x48\x61\x73\40\x43\x6f\156\164\141\x69\156\x65\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
