<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\164\141\x72\x74\40\x53\x68\157\x72\x74\x63\157\144\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\163\137\143\x6f\x6e\x74\141\151\x6e\x65\162", __("\110\141\163\40\x43\x6f\x6e\164\x61\x69\x6e\145\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
