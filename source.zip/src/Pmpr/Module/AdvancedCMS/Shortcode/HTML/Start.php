<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\x74\141\x72\x74\40\123\150\x6f\162\x74\x63\157\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\163\137\143\x6f\x6e\164\141\151\156\x65\x72", __("\x48\141\x73\40\x43\157\x6e\164\x61\x69\x6e\145\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
