<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a688816c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\164\x61\x72\164\x20\123\150\157\x72\x74\143\157\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\x73\137\143\x6f\x6e\164\141\151\156\145\162", __("\110\x61\163\x20\x43\157\x6e\x74\x61\x69\x6e\145\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
