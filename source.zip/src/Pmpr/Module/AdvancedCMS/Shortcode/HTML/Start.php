<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfe0898f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\x53\x74\x61\x72\x74\x20\123\150\x6f\162\164\x63\x6f\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\x73\x5f\143\x6f\156\164\x61\151\156\x65\162", __("\x48\x61\x73\40\103\157\156\164\141\151\x6e\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
