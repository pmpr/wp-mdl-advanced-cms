<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66bd214a48270             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\164\141\x72\x74\40\x53\x68\x6f\162\164\x63\x6f\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\163\137\143\x6f\x6e\164\x61\151\156\145\162", __("\x48\141\163\40\x43\x6f\x6e\164\141\151\156\x65\x72", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
