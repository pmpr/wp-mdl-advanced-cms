<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\x74\141\162\x74\40\x53\x68\x6f\x72\x74\x63\x6f\144\x65", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\x68\141\163\x5f\143\x6f\156\164\x61\151\156\x65\x72", __("\110\x61\163\x20\103\x6f\156\x74\x61\x69\156\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
