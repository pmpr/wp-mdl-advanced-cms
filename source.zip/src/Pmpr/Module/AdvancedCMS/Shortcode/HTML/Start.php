<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bd44842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Start extends HTML { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ywswaeisusymaeii; $this->title = __("\123\x74\x61\x72\x74\40\x53\150\x6f\x72\x74\143\157\x64\145", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::wcwmusaouiqaqeww("\150\141\x73\x5f\143\x6f\156\164\141\x69\x6e\145\x72", __("\110\141\163\x20\103\157\x6e\164\141\151\x6e\145\162", PR__MDL__ADVANCED_CMS))->iyouqgqicyqkiswi(4))); } }
