<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f0bb597             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\HTML; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class HTML extends Segment { public function __construct() { $this->parent = self::gsqoooskigukokks; parent::__construct(); } }
