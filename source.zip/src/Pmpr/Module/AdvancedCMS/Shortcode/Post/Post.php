<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Post; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Post extends Segment { public function __construct() { $this->target = self::aacsuuycgqoywikw; $this->parent = self::mswoacegomcucaik; parent::__construct(); } }
