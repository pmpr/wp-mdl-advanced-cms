<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Post; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Post extends Segment { public function __construct() { $this->target = self::aacsuuycgqoywikw; $this->parent = Constants::mswoacegomcucaik; parent::__construct(); } }
