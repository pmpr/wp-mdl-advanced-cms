<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bd44842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Right extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ggokgkyiweugsokc; $this->title = __("\x52\151\147\150\164\x73", PR__MDL__ADVANCED_CMS); } }
