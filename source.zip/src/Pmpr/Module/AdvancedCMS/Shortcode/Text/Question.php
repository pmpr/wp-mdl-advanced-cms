<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4afe9b772             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Question extends Text { const eeiymeksiysiuemu = "\x61\x6e\x73\167\145\162"; const kuygeqomywoykkai = "\161\x75\145\x73\164\x69\157\x6e"; public function gogaagekwoisaqgu() { $this->icon = IconInterface::ikkaikqgoksomqoq; $this->title = __("\121\x75\x65\x73\164\x69\157\x6e", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::kuygeqomywoykkai, __("\x51\x75\145\163\164\151\157\x6e", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::eeiymeksiysiuemu, __("\101\156\163\x77\x65\x72", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->jyumyyugiwwiqomk(100)); } }
