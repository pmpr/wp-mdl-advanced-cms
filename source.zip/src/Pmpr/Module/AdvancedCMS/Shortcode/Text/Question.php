<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a435003b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Question extends Text { const eeiymeksiysiuemu = 'answer'; const kuygeqomywoykkai = 'question'; public function gogaagekwoisaqgu() { $this->icon = IconInterface::ikkaikqgoksomqoq; $this->title = __('Question', PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::kuygeqomywoykkai, __('Question', PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::eeiymeksiysiuemu, __('Answer', PR__MDL__ADVANCED_CMS))->gsomueooycksswcy()->iyouqgqicyqkiswi(6))->jyumyyugiwwiqomk(100)); } }
