<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Example extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::gmwqguqsyyuasomc; $this->title = __("\105\x78\141\155\160\x6c\x65", PR__MDL__ADVANCED_CMS); } }
