<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630305d72745             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Example extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::gmwqguqsyyuasomc; $this->title = __("\x45\170\141\x6d\x70\154\x65", PR__MDL__ADVANCED_CMS); } }
