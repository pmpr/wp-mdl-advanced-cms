<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Example extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::gmwqguqsyyuasomc; $this->title = __("\105\x78\x61\x6d\160\x6c\x65", PR__MDL__ADVANCED_CMS); } }
