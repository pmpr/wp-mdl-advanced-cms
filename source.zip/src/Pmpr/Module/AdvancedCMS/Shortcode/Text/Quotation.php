<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf79544b07             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Quotation extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::yqaouicemawuocgm; $this->title = __("\x51\x75\157\164\x61\x74\x69\157\x6e", PR__MDL__ADVANCED_CMS); } }
