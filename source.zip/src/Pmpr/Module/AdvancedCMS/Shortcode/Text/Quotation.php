<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Quotation extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::yqaouicemawuocgm; $this->title = __("\121\x75\x6f\x74\x61\x74\x69\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
