<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058826045ea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Quotation extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::yqaouicemawuocgm; $this->title = __("\121\x75\157\x74\x61\164\x69\x6f\156", PR__MDL__ADVANCED_CMS); } }
