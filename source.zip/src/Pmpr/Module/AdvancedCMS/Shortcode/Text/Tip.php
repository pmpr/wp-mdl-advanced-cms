<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a435003b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Tip extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::muqqeuwgookecwyg; $this->title = __('Tip', PR__MDL__ADVANCED_CMS); } }
