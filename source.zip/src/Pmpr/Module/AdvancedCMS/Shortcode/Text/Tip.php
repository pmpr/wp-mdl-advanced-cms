<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Tip extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::muqqeuwgookecwyg; $this->title = __("\124\151\x70", PR__MDL__ADVANCED_CMS); } }
