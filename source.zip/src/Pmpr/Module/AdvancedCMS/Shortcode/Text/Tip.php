<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Tip extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::muqqeuwgookecwyg; $this->title = __("\x54\x69\160", PR__MDL__ADVANCED_CMS); } }
