<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\x53\164\141\x74\x73\40\141\x6e\x64\x20\x49\156\x66\x6f\x72\x6d\141\x74\x69\157\x6e", PR__MDL__ADVANCED_CMS); } }
