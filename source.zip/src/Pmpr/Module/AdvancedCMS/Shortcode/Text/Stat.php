<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a688816c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\x53\164\141\x74\x73\40\x61\156\144\x20\x49\x6e\x66\x6f\162\x6d\x61\164\x69\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
