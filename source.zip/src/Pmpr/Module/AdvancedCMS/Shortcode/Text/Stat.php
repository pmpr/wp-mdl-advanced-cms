<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Stat extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::swuawocyuuooooow; $this->title = __("\123\164\x61\x74\x73\40\141\x6e\144\40\111\x6e\146\x6f\x72\155\141\164\x69\x6f\x6e", PR__MDL__ADVANCED_CMS); } }
