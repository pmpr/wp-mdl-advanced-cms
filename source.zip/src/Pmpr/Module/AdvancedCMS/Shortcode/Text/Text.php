<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Text extends Segment { public function __construct() { $this->parent = Constants::TEXT; $this->target = self::aacsuuycgqoywikw; if (!(self::uqggkiomyiceyooa() === self::class)) { goto yiceawuuiusakwiq; } $this->target = self::iswqqwqguucescay; yiceawuuiusakwiq: parent::__construct(); } public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\x54\x65\170\x74", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\x54\x65\170\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())->jyumyyugiwwiqomk(100)); } }
