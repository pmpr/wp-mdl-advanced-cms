<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f89be1205             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Text extends Segment { public function __construct() { $this->parent = Constants::TEXT; $this->target = self::aacsuuycgqoywikw; if (static::class === self::class) { $this->target = self::iswqqwqguucescay; } parent::__construct(); } public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __('Text', PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __('Text', PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())->jyumyyugiwwiqomk(100)); } }
