<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf79544b07             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Text extends Segment { public function __construct() { $this->parent = self::TEXT; $this->target = self::aacsuuycgqoywikw; if (!(self::uqggkiomyiceyooa() === self::class)) { goto kecwuwwcwokuksyq; } $this->target = self::iswqqwqguucescay; kecwuwwcwokuksyq: parent::__construct(); } public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\124\145\170\x74", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\x54\x65\x78\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())->jyumyyugiwwiqomk(100)); } }
