<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Notice extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::mywokuksssuaquke; $this->title = __("\x4e\x6f\164\151\x63\145", PR__MDL__ADVANCED_CMS); } }
