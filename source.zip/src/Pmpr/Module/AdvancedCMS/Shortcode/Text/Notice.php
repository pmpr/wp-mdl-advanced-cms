<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Notice extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::mywokuksssuaquke; $this->title = __("\116\x6f\164\151\x63\x65", PR__MDL__ADVANCED_CMS); } }
