<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Notice extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::mywokuksssuaquke; $this->title = __("\116\x6f\x74\x69\143\x65", PR__MDL__ADVANCED_CMS); } }
