<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf79544b07             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Notice extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::mywokuksssuaquke; $this->title = __("\x4e\157\x74\151\143\145", PR__MDL__ADVANCED_CMS); } }
