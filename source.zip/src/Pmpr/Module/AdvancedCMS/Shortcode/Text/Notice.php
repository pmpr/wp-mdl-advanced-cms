<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2b5e1b58bd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Notice extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::mywokuksssuaquke; $this->title = __('Notice', PR__MDL__ADVANCED_CMS); } }
