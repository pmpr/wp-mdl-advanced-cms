<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bd44842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\106\x72\145\145\40\102\x6f\170", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto ocokwuuquaokmasc; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; ocokwuuquaokmasc: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
