<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a688816c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\x46\x72\x65\145\40\102\157\170", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto ickcmqoiosquugwe; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; ickcmqoiosquugwe: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
