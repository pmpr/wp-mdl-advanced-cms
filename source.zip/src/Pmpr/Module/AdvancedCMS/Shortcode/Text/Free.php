<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\x46\x72\x65\145\x20\x42\x6f\x78", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto iomcaiwewsawiamu; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; iomcaiwewsawiamu: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
