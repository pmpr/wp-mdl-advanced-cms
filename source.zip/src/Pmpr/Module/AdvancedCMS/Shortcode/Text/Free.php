<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfe0898f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\x46\162\145\145\x20\102\157\x78", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto eeqesooyqagwawae; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; eeqesooyqagwawae: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
