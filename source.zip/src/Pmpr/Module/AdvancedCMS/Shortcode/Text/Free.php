<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058826045ea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\106\x72\145\x65\x20\102\157\x78", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto oqugqwcyomiaaoqu; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; oqugqwcyomiaaoqu: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
