<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Free extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::wmygqmueoowayyae; $this->title = __("\106\162\x65\145\40\102\x6f\x78", PR__MDL__ADVANCED_CMS); } public function kyaweigsqwomykaa($wwgucssaecqekuek = []) : array { if (!(self::uqggkiomyiceyooa() === self::class)) { goto eeqesooyqagwawae; } $wwgucssaecqekuek[self::qescuiwgsyuikume] = ''; eeqesooyqagwawae: return parent::kyaweigsqwomykaa($wwgucssaecqekuek); } }
