<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Wrong extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ucomcyskmkiqysee; $this->title = __("\x57\162\157\156\147\163", PR__MDL__ADVANCED_CMS); } }
