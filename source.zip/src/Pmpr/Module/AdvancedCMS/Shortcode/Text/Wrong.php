<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Wrong extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ucomcyskmkiqysee; $this->title = __("\127\x72\x6f\x6e\x67\x73", PR__MDL__ADVANCED_CMS); } }
