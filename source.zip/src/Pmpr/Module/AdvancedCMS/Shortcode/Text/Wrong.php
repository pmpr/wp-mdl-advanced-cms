<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc03801c81             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Text; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Wrong extends Text { public function gogaagekwoisaqgu() { $this->icon = IconInterface::ucomcyskmkiqysee; $this->title = __("\x57\x72\x6f\156\x67\x73", PR__MDL__ADVANCED_CMS); } }
