<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50360386             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Prerequisite extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::imoykkmkkkaqgouo; $this->title = __("\x50\x72\145\162\145\161\165\x69\163\x69\164\x65", PR__MDL__ADVANCED_CMS); } }
