<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Prerequisite extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::imoykkmkkkaqgouo; $this->title = __("\120\162\145\x72\145\161\x75\x69\x73\151\164\x65", PR__MDL__ADVANCED_CMS); } }
