<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a688816c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Prerequisite extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::imoykkmkkkaqgouo; $this->title = __("\x50\x72\x65\162\145\161\x75\151\163\x69\164\145", PR__MDL__ADVANCED_CMS); } }
