<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf79544b07             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\x57\151\153\151\160\145\x64\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\114\x69\156\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\164\x74\x70\x73\x3a\x2f\57\x66\141\56\167\x69\x6b\151\160\x65\x64\x69\141\x2e\x6f\162\147\57\167\x69\x6b\151\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\x54\145\x78\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
