<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a688816c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\x57\151\153\151\160\145\144\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\114\x69\x6e\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\x74\x74\x70\163\72\x2f\x2f\x66\141\56\x77\151\153\x69\160\145\144\x69\x61\x2e\x6f\x72\x67\57\167\x69\153\151\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\x54\145\170\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
