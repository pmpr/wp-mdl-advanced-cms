<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6cbeee4b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\151\153\x69\160\145\144\151\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __("\x4c\x69\156\x6b", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\164\164\160\163\x3a\57\57\x66\x61\x2e\167\x69\x6b\x69\160\145\144\x69\x61\x2e\x6f\x72\x67\x2f\x77\x69\x6b\x69\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __("\x54\145\170\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
