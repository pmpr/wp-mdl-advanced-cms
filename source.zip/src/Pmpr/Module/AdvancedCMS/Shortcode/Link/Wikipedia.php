<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f0bb597             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\x69\x6b\x69\160\145\144\151\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\x4c\x69\x6e\x6b", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\164\164\160\x73\72\x2f\x2f\x66\x61\x2e\167\x69\x6b\x69\x70\145\144\151\141\56\157\162\x67\57\x77\x69\x6b\151\57")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\124\x65\x78\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
