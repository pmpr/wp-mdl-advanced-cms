<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\x57\151\x6b\x69\160\x65\x64\151\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\x4c\151\156\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\150\164\x74\x70\x73\72\57\57\x66\x61\56\x77\151\x6b\151\x70\145\x64\x69\x61\x2e\x6f\162\x67\x2f\x77\x69\153\x69\57")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\124\145\x78\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
