<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f89be1205             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = Constants::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __('Wikipedia', PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::ogigqueukwysusii, __('Link', PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua('https://fa.wikipedia.org/wiki/')->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::TEXT, __('Text', PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
