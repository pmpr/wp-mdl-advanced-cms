<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e411869b0b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\151\153\x69\x70\145\x64\x69\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\114\151\156\x6b", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\164\x74\x70\x73\72\x2f\57\x66\141\x2e\167\x69\x6b\x69\160\x65\x64\151\141\56\157\x72\147\57\167\x69\x6b\x69\57")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\x54\145\x78\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
