<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56bd44842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\x57\x69\x6b\151\160\145\144\x69\x61", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\114\151\x6e\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\164\x74\x70\x73\72\x2f\x2f\x66\141\x2e\167\151\153\x69\160\x65\144\x69\x61\x2e\157\x72\147\x2f\x77\x69\x6b\151\57")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\124\145\170\164", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
