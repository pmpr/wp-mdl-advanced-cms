<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dbfe0898f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconBrandInterface; class Wikipedia extends Link { public function __construct() { parent::__construct(); $this->parent = self::wouqosqskyksymwy; } public function gogaagekwoisaqgu() { $this->icon = IconBrandInterface::iwseucqoaiqmmsas; $this->title = __("\127\151\153\x69\160\x65\144\x69\141", PR__MDL__ADVANCED_CMS); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(self::ogigqueukwysusii, __("\x4c\151\x6e\153", PR__MDL__ADVANCED_CMS))->eyygsasuqmommkua("\x68\x74\164\x70\163\x3a\57\x2f\x66\x61\56\167\151\153\x69\160\145\x64\151\x61\56\x6f\162\147\57\167\x69\x6b\x69\x2f")->yskkmqiusguummwa())->mkksewyosgeumwsa(self::sciaycsmsiekqueg(self::TEXT, __("\x54\x65\x78\x74", PR__MDL__ADVANCED_CMS))->gsomueooycksswcy())); } }
