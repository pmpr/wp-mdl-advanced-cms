<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e283e018             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = Constants::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(Constants::ogigqueukwysusii, __('Link', PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai('post')->ccmwycqioaicegoc(__('Select a post', PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
