<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec394cea5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = Constants::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(Constants::ogigqueukwysusii, __("\x4c\151\156\153", PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai("\160\x6f\163\x74")->ccmwycqioaicegoc(__("\x53\145\154\x65\143\x74\x20\141\x20\160\x6f\163\x74", PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
