<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f0bb597             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = self::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(self::ogigqueukwysusii, __("\x4c\x69\156\153", PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai("\160\x6f\163\164")->ccmwycqioaicegoc(__("\123\145\154\x65\143\164\x20\141\40\160\157\x73\x74", PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
