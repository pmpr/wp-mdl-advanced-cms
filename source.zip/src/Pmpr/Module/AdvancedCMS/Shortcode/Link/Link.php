<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab909b674c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Module\AdvancedCMS\Shortcode\Segment; class Link extends Segment { public function __construct() { $this->parent = self::wwmgeoymmaiymyym; $this->target = self::aacsuuycgqoywikw; parent::__construct(); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ckuwucygcwsiawms(self::ogigqueukwysusii, __("\x4c\151\156\153", PR__MDL__ADVANCED_CMS))->smmismmuuccmscya()->oeewiaacscgyamai("\160\x6f\x73\x74")->ccmwycqioaicegoc(__("\x53\145\154\145\x63\x74\x20\x61\40\x70\157\163\164", PR__MDL__ADVANCED_CMS)))->jyumyyugiwwiqomk(100)); } }
