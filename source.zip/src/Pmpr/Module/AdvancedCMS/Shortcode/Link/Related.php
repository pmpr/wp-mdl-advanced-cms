<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f0bb597             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Related extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::csgwgkuuasoawegc; $this->title = __("\x52\145\x6c\x61\x74\x65\144", PR__MDL__ADVANCED_CMS); } }
