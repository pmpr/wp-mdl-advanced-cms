<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e680a4c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Related extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::csgwgkuuasoawegc; $this->title = __("\x52\x65\154\141\164\145\x64", PR__MDL__ADVANCED_CMS); } }
