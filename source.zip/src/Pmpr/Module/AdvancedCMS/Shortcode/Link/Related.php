<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Related extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::csgwgkuuasoawegc; $this->title = __("\122\145\154\141\164\145\x64", PR__MDL__ADVANCED_CMS); } }
