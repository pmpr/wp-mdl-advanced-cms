<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b914a6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Recommend extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::sassayqqokogegcw; $this->title = __("\122\x65\x63\x6f\155\x6d\x65\x6e\x64", PR__MDL__ADVANCED_CMS); } }
