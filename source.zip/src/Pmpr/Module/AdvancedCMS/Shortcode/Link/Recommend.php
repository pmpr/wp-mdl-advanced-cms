<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116c94039             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Recommend extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::sassayqqokogegcw; $this->title = __("\x52\145\x63\x6f\x6d\155\x65\156\x64", PR__MDL__ADVANCED_CMS); } }
