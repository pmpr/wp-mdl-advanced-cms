<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66058826045ea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AdvancedCMS\Shortcode\Link; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Recommend extends Link { public function gogaagekwoisaqgu() { $this->icon = IconInterface::sassayqqokogegcw; $this->title = __("\122\x65\x63\157\x6d\155\x65\156\144", PR__MDL__ADVANCED_CMS); } }
